package data_types;
public class Data_type {

	public static void main(String[] args) {
		
		//byte size-1byte
		 byte a=127;
		 System.out.println("1)byte="+a);
		 
		 //short size-2byte
		 short b=40;
		 System.out.println("2)short="+b);
		 
		 //int size-4byte
		 int c=600;
		 System.out.println("3)integer="+c);
		 
		 //long size-8byte
		 long d=40000l;
		 System.out.println("4)long="+d);
		 
		 //float size-4 byte
		 float e=34.4f;
		 System.out.println("5)float="+e);
		 
		 //double size=8byte
		 double f=345674d;
		 System.out.println("6)double="+f);
		 
		 //boolean size-1byte
		 boolean x=true;
		 boolean y=false;
		 System.out.println("7)boolean type="+x+" "+y);
		 
		 //char size-2byte
		 char m='D';
		 System.out.println("8)char type="+m);
		 
		 //String 
         String s="abc";
         System.out.println("9)String="+s);
         
       
	}

}
