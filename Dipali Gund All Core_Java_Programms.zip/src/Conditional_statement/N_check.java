package Conditional_statement;

import java.util.Scanner;

public class N_check {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 Scanner sc=new Scanner(System.in);
	      System.out.println("Enter the No::");
	      int a=sc.nextInt();
	      if(a>0)
	      {
	    	  System.out.println("No is positive");  
	      }
	      else
	      {
	    	  System.out.println("No is Negative"); 
	      }
		}

	}


