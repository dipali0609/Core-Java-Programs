package Conditional_statement;

public class Area {

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
      int l=20;
      int b=30;
      int area;
      area=l*b;
      System.out.println("area="+area);
      
      final double p=3.14;
      int r=2;
      double area2;
      area2=p*r*r;
      System.out.println("area="+area2);
      
	}

}
