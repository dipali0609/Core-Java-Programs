package Conditional_statement;
import java.util.*;
public class if_statement {

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the No::");
		int no=sc.nextInt();
		 if(no>10)
		 {
			 System.out.println("No is greter than 10");
		 }
		 
	}

}
