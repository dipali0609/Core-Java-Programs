package Java_operator;

public class Unary_operator
{
public static void main(String[] args) {
	int x=10;
	int y=20;
	x++;
	++y;
	System.out.println(x);
	System.out.println(y);
	
	x--;
	--y;
	System.out.println(x);
	System.out.println(y);
	
	int a=10;
	int b=10;
	System.out.println(a++);
	System.out.println(a);
	System.out.println(++b);
	System.out.println(b);
	
	
}
}
