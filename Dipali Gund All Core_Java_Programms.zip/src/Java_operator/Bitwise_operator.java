package Java_operator;

public class Bitwise_operator {

	public static void main(String[] args)
	{
		// TODO Auto-generated method stub
		int a=5,b=7;
		System.out.println(~a);
		System.out.println(a|b);
		System.out.println(a&b);
		System.out.println(a^b);
	}

}
