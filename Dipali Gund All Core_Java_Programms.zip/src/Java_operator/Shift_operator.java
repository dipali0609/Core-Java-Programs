package Java_operator;

public class Shift_operator {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(10<<2);	
		System.out.println(5<<2);	
		System.out.println(10>>2);	
		System.out.println(5>>3);	
	}

}
