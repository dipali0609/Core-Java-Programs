package Java_operator;

public class Assignment_operator {

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
    int a=10;
    int b=20;
    
    a+=b;
    System.out.println(a);
    System.out.println(b);
    
    b-=a;
    System.out.println(a);
    System.out.println(b);
   
    
	}

}
