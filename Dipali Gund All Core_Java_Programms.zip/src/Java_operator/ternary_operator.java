package Java_operator;

public class ternary_operator {

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
    int a=200,b=400,c;
    c=(a>b)?a:b;
    System.out.println(c);
	}

}
