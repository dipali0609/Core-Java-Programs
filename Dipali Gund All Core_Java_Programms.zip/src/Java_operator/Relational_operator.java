package Java_operator;

public class Relational_operator {

	public static void main(String[] args)
	{
		// TODO Auto-generated method stub
		int a=20;
		int b=10;
		//System.out.println(a==b);
		
//		System.out.println(a!=b);
//		System.out.println(a>b);
//		System.out.println(a<b);
//		System.out.println(a>=b);
//		System.out.println(a<=b);
		
   
	}

}
