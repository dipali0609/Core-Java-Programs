package Corejavaprogrames;

class instancevar
{

	int a=20;
	int b=40;
}
public class Instance_var 
{
public static void main(String[] args) 
{
	instancevar obj=new instancevar();
	System.out.println(obj.a);
	System.out.println(obj.b);
	
}
}
