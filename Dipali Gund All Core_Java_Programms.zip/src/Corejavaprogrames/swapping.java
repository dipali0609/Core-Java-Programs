package Corejavaprogrames;

public class swapping {

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
      int a=10,b=20,c;
      System.out.println("before swapping A ::"+a);
      System.out.println("before swapping B::"+b);
      
      c=a;
      a=b;
      b=c;
      System.out.println("after swapping A::"+a);
      System.out.println("after swapping B::"+b);
      
	}

}
