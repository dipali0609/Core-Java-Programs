package Corejavaprogrames;

public class HelloWorld 
{
public static void main(String[] args)
{
System.out.println("Hello World!");	
System.out.println("Dipali Gund");	
System.out.println("Hi\nHow are you\tdoing!");	

}
}
