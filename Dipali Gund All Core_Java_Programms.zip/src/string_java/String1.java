package string_java;

public class String1 
{
public static void main(String[] args) {
	String s1="String Program1";
	
	String s2=new String("String Program2");
	
	char ch[]={'s','t','r','i','n','g'};
	
	String s3=new String(ch);
	
	System.out.println(s1);
	System.out.println(s2);
	System.out.println(s3);
}
}
