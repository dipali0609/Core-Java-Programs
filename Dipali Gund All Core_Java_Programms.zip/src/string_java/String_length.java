package string_java;

public class String_length 
{
public static void main(String[] args) {
	char ch[]={'D','I','P','A','L','I'};
	String str=new String(ch);
	
	System.out.println("String ="+str);
	System.out.println("Length="+str.length());
	System.out.println("Length="+"Java Programming Example".length());
}
}
