package Looping_java;

public class While_loop
{
public static void main(String[] args)
{
	//int i=1;
//	while(i<=100)
//	{
//		System.out.println(i);
//		i++;
//	}
	
	int i=100;
	while(i>=1)
	{
	System.out.println(i);
	i--;
	}
	
	
}
}
