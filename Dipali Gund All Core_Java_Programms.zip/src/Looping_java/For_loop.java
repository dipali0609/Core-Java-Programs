package Looping_java;

public class For_loop {
public static void main(String[] args) {
	
	int i;
//	for(i=1;i<=100;i++)
//	{
//		System.out.println(i);
//	}
	
	for(i=100;i>=0;i--)
	{
		System.out.println(i);
	}
}
}
