package Looping_java;

public class even_no
{
public static void main(String[] args) {
	
int i;
for(i=1;i<=100;i++)
{
	if(i%2==0)
	{
	System.out.println("even="+i);
	}
	
}
}
}
