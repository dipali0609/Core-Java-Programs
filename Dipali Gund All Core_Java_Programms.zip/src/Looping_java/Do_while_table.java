package Looping_java;

public class Do_while_table 
{
public static void main(String[] args) {
	int n=2;
	int i=1;
	int t=1;
	do{
		t=n*i;
		System.out.println(t);
		i++;
	}while(i<=10);
}
}
