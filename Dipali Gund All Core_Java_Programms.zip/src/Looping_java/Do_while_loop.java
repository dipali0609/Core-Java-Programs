package Looping_java;

public class Do_while_loop {

}
