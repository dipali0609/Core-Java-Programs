package Looping_java;

public class odd_no 
{
	public static void main(String[] args) {
		
		int i;
		for(i=1;i<=100;i++)
		{
			if(i%2==1)
			{
			System.out.println("odd="+i);
			}
		}
		}
}
