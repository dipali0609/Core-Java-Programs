package Looping_java;

public class While_Sum_series 
{
public static void main(String[] args) {
	int sum=0,i=1;
	while(i<=100)
	{
	System.out.println(i);
	sum=sum+i;
	i++;
	}
	System.out.println(sum);
}
}
