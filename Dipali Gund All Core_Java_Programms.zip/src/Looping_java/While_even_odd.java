package Looping_java;

public class While_even_odd 
{
public static void main(String[] args) {
	int i=1;
	while(i<=100)
	{
		if(i%2==0)
		{
			System.out.println(i);
		}
		i++;
	}
	
//	int i=1;
//	while(i<=100)
//	{
//		if(i%2==1)
//		{
//			System.out.println(i);
//		}
//		i++;
//	}
}
}
