package Looping_java;

public class SumOf_even_no {
public static void main(String[] args) {
//	int sum=0,i=0;//sum of even no
//	while(i<=100)
//	{
//		sum=sum+i;
//		System.out.println(i);
//		i=i+2;
//	}
//	System.out.println("Sum Of even No::"+sum);
	
	
	int sum=0,i=1;//sum of odd no
	while(i<=100)
	{
		sum=sum+i;
		System.out.println(i);
		i=i+2;
	}
	System.out.println("sum of odd No::"+sum);
}
}
