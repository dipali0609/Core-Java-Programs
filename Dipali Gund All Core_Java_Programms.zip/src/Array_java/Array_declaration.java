package Array_java;

public class Array_declaration
{
public static void main(String[] args) {
	int a[]={2,7,5,6,8};
//	System.out.println(a[0]);
//	System.out.println(a[1]);
//	System.out.println(a[2]);
//	System.out.println(a[3]);
	
	for(int i=0;i<4;i++)
	{
		System.out.println(a[i]);
	}
}
}
