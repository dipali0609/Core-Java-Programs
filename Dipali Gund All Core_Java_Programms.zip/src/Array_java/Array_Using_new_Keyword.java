package Array_java;

public class Array_Using_new_Keyword 
{
public static void main(String[] args) {
	
	int a[]=new int[4];
	a[0]=10;
	a[1]=70;
	a[2]=40;
	a[3]=20;
	for(int i=0;i<4;i++)
	{
		System.out.println(a[i]);
	}
	
}
}
