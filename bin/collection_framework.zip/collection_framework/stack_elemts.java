package collection_framework;
import java.util.Stack;
import java.util.List;

public class stack_elemts 
{
	public static void main(String[] args)   
	{  
	List<Integer> stk= new Stack();  
	 
	stk.add(23);  
	stk.add(45);  
	
	System.out.println("Elements in Stack: " + stk);  
	 
	}  
}
