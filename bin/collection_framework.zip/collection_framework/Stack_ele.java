package collection_framework;
import java.util.Stack;
public class Stack_ele 
{
public static void main(String[] args) 
{
Stack str=new Stack();	

str.push(123);
str.push("dipali");
str.push(89);
str.push("xys");
str.push(11);
str.push("iol");
System.out.println(str);
str.pop();
System.out.println(str);

}
}
