package collection_framework;

import java.util.*;

public class HashMapEx
{
	public static void main(String[] args)
	{
		HashMap<String, Integer> hs=new HashMap<String, Integer>();
		hs.put("Two", 2);
		hs.put("Three", 3);
		hs.put("Four", 4);
		hs.put("five", 5);
		hs.put("six", 6);
		hs.put("seven", 7);	
		
	}


}
